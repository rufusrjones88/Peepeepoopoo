#include "../model.h"   // build: g++ -std=c++17 -I <ArduinoJson>/src host_test.cpp
#include <cstdio>
#include <cassert>
int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok: %s\n", msg); } while (0)
int main() {
  // --- time parsing
  CHECK(isoToUnix("1970-01-01T00:00:00Z") == 0, "epoch");
  CHECK(isoToUnix("2026-10-20T21:00:00Z") == 1792530000LL, "2026-10-20 21:00Z");
  // --- Kalshi markets through the same filter the ESP32 uses (strings for prices, extra junk fields, a 2nd page cursor)
  const char* km = R"({"markets":[
    {"ticker":"KXBTCD-26OCT2017-T67249.99","event_ticker":"KXBTCD-26OCT2017","yes_sub_title":"$67,250 or above","strike_type":"greater","floor_strike":67249.99,
     "yes_bid_dollars":"0.4500","yes_ask_dollars":"0.4700","last_price_dollars":"0.4600","close_time":"2026-10-20T21:00:00Z","expected_expiration_time":"2026-10-20T21:00:00Z","rules_primary":"long text....","volume_fp":"1234.00"},
    {"ticker":"KXBTCD-26OCT2017-T66249.99","event_ticker":"KXBTCD-26OCT2017","strike_type":"greater","floor_strike":66249.99,
     "yes_bid_dollars":"0.9100","yes_ask_dollars":"0.9300","close_time":"2026-10-20T21:00:00Z","expected_expiration_time":null},
    {"ticker":"KXBTC-26OCT2017-B67000","event_ticker":"KXBTC-26OCT2017","strike_type":"between","floor_strike":66750,"cap_strike":67249.99,
     "yes_bid_dollars":0.20,"yes_ask_dollars":0.23,"close_time":"2026-10-20T21:00:00Z"}
  ],"cursor":"abc123"})";
  JsonDocument f; kalshiFilter(f);
  JsonDocument d; auto err = deserializeJson(d, km, DeserializationOption::Filter(f));
  CHECK(!err, "kalshi json parses with filter");
  CHECK(d["markets"][0]["rules_primary"].isNull(), "filter drops unused fields");
  std::vector<Market> mk; std::string cur = parseMarkets(d, mk);
  CHECK(mk.size() == 3 && cur == "abc123", "3 markets + cursor");
  CHECK(fabs(mk[0].yesAsk - 0.47) < 1e-6 && fabs(mk[2].yesBid - 0.20) < 1e-6, "string and number prices both read");
  CHECK(mk[1].expTs == 0 && mk[1].closeTs == 1792530000LL, "null expiration falls back to close time");
  // --- volatility from candles (newest first). Build a gentle zigzag around 67,000.
  std::string cj = "["; double px = 67000; for (int i = 0; i < 300; i++) { double c = px * (1 + ((i % 2) ? 0.0005 : -0.0005)); char b[96]; snprintf(b, sizeof b, "%s[%d,%f,%f,%f,%f,1.0]", i ? "," : "", 1792526400 - 60 * i, c, c, c, c); cj += b; } cj += "]";
  JsonDocument cd; deserializeJson(cd, cj); double last = 0; double v = minuteVol(cd, &last);
  CHECK(v > 0.0009 && v < 0.0011 && fabs(last - 67000 * 0.9995) < 1, "1-minute vol ~0.1% from zigzag candles");
  long long now = 1792530000LL - 1800;    // 30 minutes to expiry
  double spot = 67250.0;
  double p0 = cryptoProbYes(mk[0], spot, 0.0008, now, 1.0);
  CHECK(fabs(p0 - 0.5) < 0.01, "spot at the strike -> ~50%");
  double p1 = cryptoProbYes(mk[1], spot, 0.0008, now, 1.0);
  double sd = 0.0008 * sqrt(30.0); double expect = normCdf(log(67250 / 66249.99) / sd);
  CHECK(fabs(p1 - expect) < 1e-5 && p1 > 0.9, "1,000 below spot -> high and matches the formula");
  double p2 = cryptoProbYes(mk[2], spot, 0.0008, now, 1.0);
  CHECK(p2 > 0.0 && p2 < 0.5, "range market probability is sensible");
  CHECK(isnan(cryptoProbYes(mk[0], spot, 0.0008, 1792530000LL + 5)), "expired market -> NAN");
  // --- 15-minute up/down
  Market ud; ud.ticker = "KXBTC15M-26OCT201715-15"; ud.closeTs = 1792530000LL; ud.yesBid = 0.48; ud.yesAsk = 0.50;
  CHECK(fabs(upDownProbYes(ud, 67000, 0.0008, 1792530000LL - 600) - 0.5) < 1e-12, "window not started (no start price) -> 50%");
  ud.floorStrike = 67000.0;
  CHECK(fabs(upDownProbYes(ud, 67000, 0.0008, 1792530000LL - 600) - 0.5) < 1e-9, "spot = start -> 50%");
  double up = upDownProbYes(ud, 67100, 0.0008, 1792530000LL - 300, 1.0, 60.0);
  double expUp = normCdf(log(67100.0 / 67000.0) / (0.0008 * sqrt((300 - 40) / 60.0)));
  CHECK(fabs(up - expUp) < 1e-12 && up > 0.75 && up < 0.88, "+100 with 5 min left (0.08%/min vol) -> ~81% up (60 s averaging counted)");
  CHECK(upDownProbYes(ud, 67100, 0.0008, 1792530000LL - 30) > upDownProbYes(ud, 67100, 0.0008, 1792530000LL - 600), "same lead, less time -> more certain");
  CHECK(upDownLabel("BTC", ud, 1792530000LL - 65) == "BTC UP 1m05s", "label shows time left");
  std::vector<Pick> picks; addBothSides(mk[1], 0.97, "x", picks);
  CHECK(picks.size() == 2 && fabs(picks[0].edge - (0.97 - 0.93)) < 1e-9 && fabs(picks[1].price - 0.09) < 1e-9 && fabs(picks[1].edge - (0.03 - 0.09)) < 1e-9, "YES/NO edges and prices");
  // --- ESPN + Kalshi game matching
  const char* es = R"({"leagues":[{"name":"x"}],"events":[
    {"status":{"type":{"state":"pre"}},"competitions":[{"venue":{"fullName":"x"},"competitors":[
      {"homeAway":"home","team":{"abbreviation":"SEA","displayName":"Seahawks"},"records":[{"summary":"6-1"},{"summary":"3-0"}]},
      {"homeAway":"away","team":{"abbreviation":"LAR"},"records":[{"summary":"2-5"}]}]}]},
    {"status":{"type":{"state":"post"}},"competitions":[{"competitors":[
      {"homeAway":"home","team":{"abbreviation":"KC"},"records":[{"summary":"5-2"}]},{"homeAway":"away","team":{"abbreviation":"BUF"},"records":[{"summary":"5-2"}]}]}]}
  ]})";
  JsonDocument ef; espnFilter(ef); JsonDocument ed; err = deserializeJson(ed, es, DeserializationOption::Filter(ef));
  CHECK(!err, "espn json parses with filter");
  std::vector<Game> gs; parseEspn(ed, gs);
  CHECK(gs.size() == 2 && gs[0].home == "SEA" && gs[0].away == "LAR" && gs[0].homeGP == 7, "games + records");
  double ph = homeWinProb(gs[0], 0.2);
  CHECK(ph > 0.70 && ph < 0.85, "6-1 home vs 2-5 -> clear favourite (shrunk toward .500)");
  Game even; even.home = "A"; even.away = "B"; even.homeWin = 0.5; even.awayWin = 0.5;
  CHECK(fabs(homeWinProb(even, 0.0) - 0.5) < 1e-9 && homeWinProb(even, 0.2) > 0.54, "even teams: 50%, home edge adds");
  std::vector<Market> gm = {{"KXNFLGAME-26OCT26LARSEA-SEA", "", "", "", NAN, NAN, 0.70, 0.72, NAN, 0, 0},
                            {"KXNFLGAME-26OCT26LARSEA-LAR", "", "", "", NAN, NAN, 0.28, 0.30, NAN, 0, 0},
                            {"KXNFLGAME-26OCT26BUFKC-KC", "", "", "", NAN, NAN, 0.5, 0.52, NAN, 0, 0}};
  std::vector<Pick> sp; int m = sportsPicks("NFL", gs, gm, 0.2, sp);
  CHECK(m == 2 && sp.size() == 4, "only the unplayed game is matched (both team markets, both sides)");
  bestFirst(sp); CHECK(sp[0].edge >= sp[1].edge && sp[1].edge >= sp[3].edge, "sorted best first");
  printf("%s (%d failures)\n", fails ? "SOME TESTS FAILED" : "ALL TESTS PASS", fails);
  return fails != 0;
}
