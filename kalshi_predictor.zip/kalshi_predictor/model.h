// model.h - the maths and JSON parsing (no WiFi / screen code), so it can be tested on a PC.
// Read-only: this never places orders.
#pragma once
#include <ArduinoJson.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <algorithm>

// ---------- small helpers ----------
inline double num(JsonVariantConst v) {               // Kalshi sends some numbers as strings ("0.5600")
  if (v.is<const char*>()) return atof(v.as<const char*>());
  return v.as<double>();
}
inline double normCdf(double x) { return 0.5 * erfc(-x / sqrt(2.0)); }
inline double clamp01(double p) { return p < 0.0 ? 0.0 : (p > 1.0 ? 1.0 : p); }
inline double logit(double p) { p = std::min(std::max(p, 1e-6), 1 - 1e-6); return log(p / (1 - p)); }
inline double ilogit(double x) { return 1.0 / (1.0 + exp(-x)); }

// ISO-8601 UTC "2026-10-20T21:00:00Z" -> unix seconds (no timezone library needed)
inline long long isoToUnix(const char* s) {
  if (!s || strlen(s) < 19) return 0;
  int Y = atoi(s), M = atoi(s + 5), D = atoi(s + 8), h = atoi(s + 11), m = atoi(s + 14), sec = atoi(s + 17);
  // days from civil (Howard Hinnant)
  Y -= M <= 2; long era = (Y >= 0 ? Y : Y - 399) / 400; unsigned yoe = (unsigned)(Y - era * 400);
  unsigned doy = (153 * (M + (M > 2 ? -3 : 9)) + 2) / 5 + D - 1; unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  long long days = era * 146097LL + (long long)doe - 719468LL;
  return days * 86400LL + h * 3600 + m * 60 + sec;
}

// ---------- one Kalshi market ----------
struct Market {
  std::string ticker, event, sub;     // sub = yes_sub_title (e.g. "$67,250 or above" or a team name)
  std::string strikeType;             // greater, greater_or_equal, less, less_or_equal, between, ...
  double floorStrike = NAN, capStrike = NAN;
  double yesBid = NAN, yesAsk = NAN, last = NAN;   // dollars (0..1) = implied probability
  long long closeTs = 0, expTs = 0;
};

// Filter so the ESP32 only keeps the fields we use (the full reply is far too big for its RAM)
inline void kalshiFilter(JsonDocument& f) {
  JsonObject m = f["markets"].add<JsonObject>();
  const char* keep[] = {"ticker", "event_ticker", "yes_sub_title", "strike_type", "floor_strike", "cap_strike",
                        "yes_bid_dollars", "yes_ask_dollars", "last_price_dollars", "close_time", "expected_expiration_time", "status"};
  for (auto k : keep) m[k] = true;
  f["cursor"] = true;
}
// Parse a /markets reply; returns the next-page cursor ("" when done)
inline std::string parseMarkets(const JsonDocument& doc, std::vector<Market>& out) {
  for (JsonObjectConst m : doc["markets"].as<JsonArrayConst>()) {
    Market k;
    k.ticker = m["ticker"] | ""; k.event = m["event_ticker"] | ""; k.sub = m["yes_sub_title"] | "";
    k.strikeType = m["strike_type"] | "";
    if (!m["floor_strike"].isNull()) k.floorStrike = num(m["floor_strike"]);
    if (!m["cap_strike"].isNull()) k.capStrike = num(m["cap_strike"]);
    if (!m["yes_bid_dollars"].isNull()) k.yesBid = num(m["yes_bid_dollars"]);
    if (!m["yes_ask_dollars"].isNull()) k.yesAsk = num(m["yes_ask_dollars"]);
    if (!m["last_price_dollars"].isNull()) k.last = num(m["last_price_dollars"]);
    k.closeTs = isoToUnix(m["close_time"] | "");
    k.expTs = isoToUnix(m["expected_expiration_time"] | "");
    out.push_back(k);
  }
  return std::string(doc["cursor"] | "");
}

// ---------- a "pick": where the model and the market disagree ----------
struct Pick {
  std::string label;      // what to show, e.g. "BTC >= 67,250" or "SEA beats LAR"
  std::string side;       // "YES" or "NO"
  double model = NAN;     // model probability that this side wins
  double price = NAN;     // what it costs to buy this side now (ask), dollars
  double edge = NAN;      // model - price (before Kalshi fees)
  long long closeTs = 0;
};
inline void addBothSides(const Market& k, double pYes, const std::string& label, std::vector<Pick>& picks,
                         const char* yesName = "YES", const char* noName = "NO") {
  // buy YES at yes_ask; buy NO at (1 - yes_bid)
  if (!isnan(k.yesAsk) && k.yesAsk > 0.0 && k.yesAsk < 1.0)
    picks.push_back({label, yesName, pYes, k.yesAsk, pYes - k.yesAsk, k.closeTs});
  if (!isnan(k.yesBid) && k.yesBid > 0.0 && k.yesBid < 1.0)
    picks.push_back({label, noName, 1.0 - pYes, 1.0 - k.yesBid, (1.0 - pYes) - (1.0 - k.yesBid), k.closeTs});
}
inline void bestFirst(std::vector<Pick>& p) { std::sort(p.begin(), p.end(), [](const Pick& a, const Pick& b) { return a.edge > b.edge; }); }

// ================= CRYPTO =================
// Coinbase 1-minute candles: [[time, low, high, open, close, volume], ...] newest first.
// Returns the volatility of 1-minute log returns (as a fraction), or NAN.
inline double minuteVol(const JsonDocument& candles, double* lastClose) {
  JsonArrayConst a = candles.as<JsonArrayConst>();
  std::vector<double> c;
  for (JsonArrayConst row : a) if (row.size() >= 5) c.push_back(num(row[4]));
  if (c.size() < 20) return NAN;
  if (lastClose) *lastClose = c[0];
  double s = 0, s2 = 0; int n = 0;
  for (size_t i = 0; i + 1 < c.size(); i++) { if (c[i] <= 0 || c[i + 1] <= 0) continue; double r = log(c[i] / c[i + 1]); s += r; s2 += r * r; n++; }
  if (n < 10) return NAN;
  double mean = s / n; return sqrt(std::max(0.0, s2 / n - mean * mean));
}
// P(price at expiry is in the YES region). Random walk, no drift; volFudge > 1 widens it for fat tails.
// avgS: Kalshi settles on a 60-second average of the index just before expiry, which shaves ~40 s off the
// effective time left (the average of the last minute moves less than the final price).
inline double sdLeft(double vol1m, double volFudge, long long t, double avgS) {
  double teff = std::max(5.0, (double)t - avgS * 2.0 / 3.0);
  return std::max(1e-6, vol1m * volFudge * sqrt(teff / 60.0));
}
inline double cryptoProbYes(const Market& k, double spot, double vol1m, long long now, double volFudge = 1.25, double avgS = 0.0) {
  long long t = (k.expTs > now ? k.expTs : k.closeTs) - now;
  if (t <= 0 || isnan(spot) || isnan(vol1m) || spot <= 0) return NAN;
  double sd = sdLeft(vol1m, volFudge, t, avgS);
  auto above = [&](double K) { return normCdf(log(spot / K) / sd); };   // P(S_T > K)
  const std::string& st = k.strikeType;
  if (st == "greater" || st == "greater_or_equal") return isnan(k.floorStrike) ? NAN : above(k.floorStrike);
  if (st == "less" || st == "less_or_equal") return isnan(k.capStrike) ? NAN : 1.0 - above(k.capStrike);
  if (st == "between") return (isnan(k.floorStrike) || isnan(k.capStrike)) ? NAN : clamp01(above(k.floorStrike) - above(k.capStrike));
  return NAN;   // other strike types: skip
}
// 15-minute UP/DOWN markets: YES = the price at the end of the window is >= the price at the start.
// The start price (floor_strike) is only known once the window has opened; before that it's a coin flip.
inline double upDownProbYes(const Market& k, double spot, double vol1m, long long now, double volFudge = 1.25, double avgS = 60.0) {
  long long t = (k.expTs > now ? k.expTs : k.closeTs) - now;
  if (t <= 0 || isnan(spot) || isnan(vol1m) || spot <= 0) return NAN;
  if (isnan(k.floorStrike) || k.floorStrike <= 0) return 0.5;
  return normCdf(log(spot / k.floorStrike) / sdLeft(vol1m, volFudge, t, avgS));
}
inline std::string upDownLabel(const char* coin, const Market& k, long long now) {
  char b[48]; long long t = (k.expTs > now ? k.expTs : k.closeTs) - now;
  snprintf(b, sizeof b, "%s UP %dm%02ds", coin, (int)(t / 60), (int)(t % 60));
  return b;
}
inline std::string cryptoLabel(const char* coin, const Market& k) {
  char b[48];
  const std::string& st = k.strikeType;
  if (st == "greater" || st == "greater_or_equal") snprintf(b, sizeof b, "%s>%.0f", coin, k.floorStrike);
  else if (st == "less" || st == "less_or_equal") snprintf(b, sizeof b, "%s<%.0f", coin, k.capStrike);
  else snprintf(b, sizeof b, "%s %.0f-%.0f", coin, k.floorStrike, k.capStrike);
  return b;
}

// ================= SPORTS =================
struct Game { std::string home, away; double homeWin = NAN, awayWin = NAN; int homeGP = 0, awayGP = 0; std::string state; };
inline void espnFilter(JsonDocument& f) {
  JsonObject e = f["events"].add<JsonObject>();
  e["status"]["type"]["state"] = true;
  JsonObject c = e["competitions"].add<JsonObject>()["competitors"].add<JsonObject>();
  c["homeAway"] = true; c["team"]["abbreviation"] = true; c["records"][0]["summary"] = true;
}
// "10-3" or "10-3-1" (ties count half)
inline void recordToWins(const char* s, double& winFrac, int& gp) {
  int w = 0, l = 0, t = 0; winFrac = NAN; gp = 0;
  if (!s || !*s) return;
  int n = sscanf(s, "%d-%d-%d", &w, &l, &t); if (n < 2) return;
  gp = w + l + t; winFrac = gp ? (w + 0.5 * t) / gp : NAN;
  // shrink toward .500 early in the season (adds 2.5 wins + 2.5 losses)
  winFrac = (w + 0.5 * t + 2.5) / (gp + 5.0);
}
inline void parseEspn(const JsonDocument& doc, std::vector<Game>& out) {
  for (JsonObjectConst e : doc["events"].as<JsonArrayConst>()) {
    Game g; g.state = e["status"]["type"]["state"] | "";
    for (JsonObjectConst c : e["competitions"][0]["competitors"].as<JsonArrayConst>()) {
      std::string side = c["homeAway"] | ""; std::string ab = c["team"]["abbreviation"] | "";
      double w; int gp; recordToWins(c["records"][0]["summary"] | "", w, gp);
      if (side == "home") { g.home = ab; g.homeWin = w; g.homeGP = gp; } else { g.away = ab; g.awayWin = w; g.awayGP = gp; }
    }
    if (!g.home.empty() && !g.away.empty()) out.push_back(g);
  }
}
// log5 + home advantage (in log-odds). Crude on purpose - the market usually knows more than this.
inline double homeWinProb(const Game& g, double homeEdgeLogit) {
  double a = isnan(g.homeWin) ? 0.5 : g.homeWin, b = isnan(g.awayWin) ? 0.5 : g.awayWin;
  double den = a + b - 2 * a * b; double p = den > 1e-9 ? (a - a * b) / den : 0.5;
  return ilogit(logit(p) + homeEdgeLogit);
}
// Kalshi game markets: one per team, ticker ends with "-<TEAM>" (e.g. KXNFLGAME-26JAN25LASEA-SEA)
inline std::string tickerTeam(const std::string& t) { size_t i = t.rfind('-'); return i == std::string::npos ? "" : t.substr(i + 1); }
inline bool tickerHasBoth(const std::string& t, const std::string& a, const std::string& b) {
  size_t i = t.find('-'); size_t j = t.rfind('-'); if (i == std::string::npos || j <= i) return false;
  std::string mid = t.substr(i + 1, j - i - 1); return mid.find(a) != std::string::npos && mid.find(b) != std::string::npos;
}
// Pair each upcoming ESPN game with its two Kalshi markets and make picks
inline int sportsPicks(const char* league, const std::vector<Game>& games, const std::vector<Market>& mk, double homeEdgeLogit, std::vector<Pick>& picks) {
  int matched = 0;
  for (const Game& g : games) {
    if (g.state != "pre") continue;                    // only games that haven't started
    double ph = homeWinProb(g, homeEdgeLogit);
    for (const Market& k : mk) {
      if (!tickerHasBoth(k.ticker, g.home, g.away)) continue;
      std::string team = tickerTeam(k.ticker);
      double p = team == g.home ? ph : (team == g.away ? 1 - ph : NAN);
      if (isnan(p)) continue;
      std::string opp = team == g.home ? g.away : g.home;
      addBothSides(k, p, std::string(league) + " " + team + " v " + opp, picks); matched++;
    }
  }
  return matched;
}
