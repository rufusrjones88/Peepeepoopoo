KALSHI EDGE FINDER  -  ESP32 + 1.54" ST7789 screen
===================================================
What it does
  CRYPTO 15 MIN page (updates every 15 s) - Kalshi's "BTC price up in next 15 mins?" markets (KXBTC15M):
      BTC +123 6m40s           <- BTC is $123 above this window's start price, 6:40 left
      UP 81%   K 74/76c        <- model: 81% it finishes up.  Kalshi: UP bid 74c / ask 76c
      BTC UP 6m40s       UP
      81% vs 76c  +5           <- an "edge": model beats the price by 5c+
    How these settle (Kalshi's rules): YES/UP if the 60-second average of the CF Benchmarks BTC index at the end of
    the window is >= the same average at the start. Before a window opens its start price isn't known -> 50%.
  SPORTS EDGES page (every 10 min) - game-winner markets vs team records + home advantage.
  STATUS page.  Pages rotate every 8 s; the BOOT button skips.
  It is READ-ONLY: it never logs in to Kalshi and cannot place trades.

Be realistic
  - These are simple models. Kalshi's prices come from people with much better models, so most "edges" are the
    model being wrong, not free money. Kalshi's fees (a few cents a contract) are not included.
  - Crypto model: BTC/ETH moves as a random walk with the volatility of the last 5 hours of 1-minute Coinbase
    candles (x1.25 for surprise jumps). Kalshi settles on its own index, not Coinbase - small differences matter
    near the strike.
  - Sports model: team win-loss records (pulled toward .500 early in the season) + home advantage. It knows
    nothing about injuries, rest, weather or quarterbacks.
  - Treat it as a fun dashboard / starting point. Not financial advice.

Wiring (1.54" ST7789 240x240 SPI module -> ESP32 dev board)
  VCC -> 3V3      GND -> GND
  SCL/SCK -> GPIO 18      SDA/MOSI -> GPIO 23
  CS -> GPIO 5 (if your module has no CS pin, set TFT_CS to -1 in config.h)
  DC -> GPIO 16   RES/RST -> GPIO 17   BLK/BL -> GPIO 4 (or 3V3)

Setup
  1. Arduino IDE: install the ESP32 boards (Espressif), board = "ESP32 Dev Module".
  2. Library Manager: ArduinoJson (7.x), Adafruit GFX Library, Adafruit ST7735 and ST7789 Library.
  3. Open kalshi_predictor.ino, put your WiFi name/password in config.h, upload.
  4. Open the Serial Monitor at 115200 to watch what it downloads.
  If the screen stays black, change SPI_MODE3 to SPI_MODE0 in setup(); if it's upside down, change setRotation(2).

Things to check / tune (config.h)
  - COINS: KXBTC15M is Kalshi's 15-minute Bitcoin up/down series. KXETH15M is my guess for Ethereum - if the
    STATUS page shows "0mk" for ETH, find the right series name on kalshi.com (it's in the market's URL) or delete
    the line. The hourly ladder (KXBTCD) is in config.h too, commented out.
  - 15-minute reality check: over 15 minutes BTC is close to a coin flip, and the model only knows the price
    so far vs the start. Kalshi traders see the same thing faster. Expect most "edges" to be noise; the useful
    part is seeing the odds move as the window runs down.
  - LEAGUES: the Kalshi game series (KXNFLGAME, KXNBAGAME, ...). Same check: the Serial Monitor prints how many
    Kalshi markets each one found.
  - ALIASES: when ESPN and Kalshi abbreviate a team differently, the Serial Monitor prints
    "no Kalshi match for X @ Y" plus an example Kalshi ticker - add {league, ESPN code, Kalshi code} to ALIASES.
  - MIN_EDGE, VOL_FUDGE, homeEdge per league: how picky / how cautious the models are.

Files
  kalshi_predictor.ino  WiFi, downloads, screen
  model.h               the maths + JSON parsing (tested on a PC: test/host_test.cpp, 24 checks pass)
  config.h              your settings
