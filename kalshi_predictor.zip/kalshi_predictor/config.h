// config.h - change these for your setup
#pragma once
// ---------- WiFi ----------
#define WIFI_SSID     "your-wifi-name"
#define WIFI_PASSWORD "your-wifi-password"

// ---------- screen: 1.54" ST7789 240x240 (SPI) ----------
// ESP32 hardware SPI: SCK = GPIO 18, MOSI (SDA on the module) = GPIO 23
#define TFT_CS   5     // set to -1 if your module has no CS pin
#define TFT_DC   16
#define TFT_RST  17
#define TFT_BL   4     // backlight pin (BLK); -1 if not connected
#define BUTTON_PIN 0   // the ESP32 "BOOT" button: press = next page

// ---------- what to show ----------
#define MIN_EDGE      0.05   // only list picks where the model beats the price by at least 5 cents
#define MIN_PRICE     0.05   // ignore contracts cheaper than 5c or dearer than 95c (thin, noisy)
#define MAX_PRICE     0.95
#define PAGE_SECONDS  8      // auto-rotate pages
#define CRYPTO_REFRESH_S  15     // 15-minute markets move fast
#define SPORTS_REFRESH_S  600
#define VOL_FUDGE     1.25   // widens the crypto model for sudden jumps (1.0 = plain random walk)

// ---------- Kalshi crypto series ----------
// upDown15 = true : the 15-minute "price up in next 15 mins?" markets (YES = ends >= the price at the start)
// upDown15 = false: the hourly "above / below $X" ladders
struct CoinCfg { const char* name; const char* kalshiSeries; const char* coinbase; bool upDown15; };
static const CoinCfg COINS[] = {
  {"BTC", "KXBTC15M", "BTC-USD", true},
  {"ETH", "KXETH15M", "ETH-USD", true},    // my guess at the name - check on kalshi.com; delete the line if it finds 0 markets
  // {"BTC", "KXBTCD", "BTC-USD", false},  // hourly ladder, if you want it as well
};

// ---------- sports: ESPN scoreboard + Kalshi game series ----------
// homeEdge = home advantage in log-odds (0.2 ~ +5% for even teams)
struct LeagueCfg { const char* name; const char* espnPath; const char* kalshiSeries; double homeEdge; };
static const LeagueCfg LEAGUES[] = {
  {"NFL", "football/nfl",              "KXNFLGAME",   0.20},
  {"NBA", "basketball/nba",            "KXNBAGAME",   0.30},
  {"NHL", "hockey/nhl",                "KXNHLGAME",   0.15},
  {"MLB", "baseball/mlb",              "KXMLBGAME",   0.15},
  {"CFB", "football/college-football", "KXNCAAFGAME", 0.30},
};
// If ESPN and Kalshi spell a team differently, add it here: {ESPN code, Kalshi code}.
// The Serial Monitor prints every game it couldn't match, with the Kalshi tickers it saw, so you can fill this in.
struct Alias { const char* league; const char* espn; const char* kalshi; };
static const Alias ALIASES[] = {
  {"NFL", "LAR", "LA"},      // example - confirm against the Serial Monitor output
};
