// KALSHI EDGE FINDER - ESP32 + 1.54" ST7789 screen.  READ-ONLY: it never logs in to Kalshi or places trades.
// Pulls live Kalshi prices, runs a simple model, and shows where the model and the market disagree.
//   Crypto: 15-minute BTC/ETH "up or down" markets (and optionally the hourly ladders) vs a random-walk model
//           fed by Coinbase prices + volatility.
//   Sports: Kalshi game-winner markets vs team records + home advantage (ESPN scoreboard).
// Libraries (Arduino Library Manager): ArduinoJson (7.x), Adafruit GFX Library, Adafruit ST7735 and ST7789 Library.
// Board: ESP32 Dev Module.  Kalshi fees are NOT included in the edges - they take a few cents per contract.
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <time.h>
#include "config.h"
#include "model.h"

static const char* KALSHI = "https://external-api.kalshi.com/trade-api/v2";
Adafruit_ST7789 tft(TFT_CS, TFT_DC, TFT_RST);

std::vector<Pick> cryptoPicks, sportPicks;
struct CoinState { double spot = NAN, vol = NAN; int markets = 0;
                   bool live = false; double start = NAN, pUp = NAN, yesBid = NAN, yesAsk = NAN; long long closeTs = 0; };
CoinState coinState[sizeof(COINS) / sizeof(COINS[0])];
int sportsMatched = 0, sportsGames = 0;
String lastError = "";
unsigned long lastCrypto = 0, lastSports = 0, lastPage = 0;
bool cryptoEverOk = false, sportsEverOk = false;
int page = 0; const int PAGES = 3;

// ---------- network ----------
// Streams the reply straight into ArduinoJson (HTTP/1.0 = no chunked encoding), keeping only the filtered fields.
bool getJson(const String& url, JsonDocument& doc, JsonDocument* filter) {
  WiFiClientSecure client; client.setInsecure();          // public read-only data; skips certificate checks
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(15000);
  if (!http.begin(client, url)) { lastError = "begin failed"; return false; }
  http.addHeader("User-Agent", "esp32-kalshi-edge/1.0");   // Coinbase rejects requests without one
  http.addHeader("Accept", "application/json");
  int code = http.GET();
  if (code != 200) { lastError = "HTTP " + String(code); Serial.printf("GET %s -> %d\n", url.c_str(), code); http.end(); return false; }
  DeserializationError err = filter ? deserializeJson(doc, http.getStream(), DeserializationOption::Filter(*filter))
                                    : deserializeJson(doc, http.getStream());
  http.end();
  if (err) { lastError = String("JSON ") + err.c_str(); Serial.printf("JSON error %s on %s\n", err.c_str(), url.c_str()); return false; }
  return true;
}
String urlEncode(const String& s) {
  String o; const char* hex = "0123456789ABCDEF";
  for (size_t i = 0; i < s.length(); i++) { char c = s[i];
    if (isalnum((unsigned char)c) || c == '-' || c == '_' || c == '.' || c == '~') o += c; else { o += '%'; o += hex[(c >> 4) & 15]; o += hex[c & 15]; } }
  return o;
}
// All pages of /markets for a query (stops after maxPages)
bool kalshiMarkets(const String& query, std::vector<Market>& out, int maxPages = 5) {
  JsonDocument f; kalshiFilter(f);
  String cursor = "";
  for (int p = 0; p < maxPages; p++) {
    String url = String(KALSHI) + "/markets?limit=200&" + query + (cursor.length() ? "&cursor=" + urlEncode(cursor) : "");
    JsonDocument d;
    if (!getJson(url, d, &f)) return false;
    std::string c = parseMarkets(d, out);
    cursor = c.c_str();
    if (!cursor.length()) break;
    delay(150);                                            // be polite to the API
  }
  return true;
}
long long nowUnix() { return (long long)time(nullptr); }

// ---------- crypto ----------
void updateCrypto() {
  std::vector<Pick> picks;
  long long now = nowUnix();
  for (size_t i = 0; i < sizeof(COINS) / sizeof(COINS[0]); i++) {
    const CoinCfg& c = COINS[i]; CoinState& cs = coinState[i];
    JsonDocument cd;
    if (!getJson(String("https://api.exchange.coinbase.com/products/") + c.coinbase + "/candles?granularity=60", cd, nullptr)) continue;
    double last = NAN; double vol = minuteVol(cd, &last);
    cs.spot = last; cs.vol = vol;
    // markets settling soon (no status filter: the API only allows close-time filters without it)
    long long ahead = c.upDown15 ? 20 * 60 : 2 * 3600;
    String q = String("series_ticker=") + c.kalshiSeries + "&min_close_ts=" + String((long)(now + 5)) + "&max_close_ts=" + String((long)(now + ahead));
    std::vector<Market> mk;
    if (!kalshiMarkets(q, mk, 3)) continue;
    cs.markets = mk.size(); cs.live = false;
    long long soonest = 0;
    for (const Market& k : mk) {
      if (c.upDown15) {
        double p = upDownProbYes(k, last, vol, now, VOL_FUDGE, 60.0);
        if (isnan(p)) continue;
        addBothSides(k, p, upDownLabel(c.name, k, now), picks, "UP", "DN");
        if (!isnan(k.yesAsk) && (!soonest || k.closeTs < soonest)) {      // the window running right now
          soonest = k.closeTs; cs.live = true; cs.start = k.floorStrike; cs.pUp = p; cs.yesBid = k.yesBid; cs.yesAsk = k.yesAsk; cs.closeTs = k.closeTs;
        }
      } else {
        double p = cryptoProbYes(k, last, vol, now, VOL_FUDGE, 60.0);
        if (isnan(p)) continue;
        addBothSides(k, p, cryptoLabel(c.name, k), picks);
      }
    }
    Serial.printf("%s spot %.2f  1m vol %.4f%%  %d Kalshi markets", c.name, last, vol * 100, (int)mk.size());
    if (cs.live) Serial.printf("  | 15m window: start %.2f, model UP %.0f%%, Kalshi UP %.0f-%.0fc, %lds left",
                               cs.start, cs.pUp * 100, cs.yesBid * 100, cs.yesAsk * 100, (long)(cs.closeTs - now));
    Serial.println("");
  }
  bestFirst(picks);
  cryptoPicks = picks; cryptoEverOk = true;
}

// ---------- sports ----------
void applyAliases(const char* league, std::vector<Game>& gs) {
  for (Game& g : gs)
    for (const Alias& a : ALIASES)
      if (!strcmp(a.league, league)) { if (g.home == a.espn) g.home = a.kalshi; if (g.away == a.espn) g.away = a.kalshi; }
}
void updateSports() {
  std::vector<Pick> picks; sportsMatched = 0; sportsGames = 0;
  for (const LeagueCfg& L : LEAGUES) {
    JsonDocument ef; espnFilter(ef); JsonDocument ed;
    if (!getJson(String("https://site.api.espn.com/apis/site/v2/sports/") + L.espnPath + "/scoreboard", ed, &ef)) continue;
    std::vector<Game> gs; parseEspn(ed, gs); applyAliases(L.name, gs);
    std::vector<Market> mk;
    if (!kalshiMarkets(String("series_ticker=") + L.kalshiSeries + "&status=open", mk, 5)) continue;
    int upcoming = 0; for (auto& g : gs) if (g.state == "pre") upcoming++;
    int m = sportsPicks(L.name, gs, mk, L.homeEdge, picks);
    sportsGames += upcoming; sportsMatched += m / 2;
    Serial.printf("%s: %d upcoming games, %d Kalshi markets, %d matched\n", L.name, upcoming, (int)mk.size(), m / 2);
    for (auto& g : gs) {                                   // help fill in ALIASES
      if (g.state != "pre") continue;
      bool found = false; for (auto& k : mk) if (tickerHasBoth(k.ticker, g.home, g.away)) { found = true; break; }
      if (!found) Serial.printf("   no Kalshi match for %s @ %s\n", g.away.c_str(), g.home.c_str());
    }
    if (mk.size()) Serial.printf("   e.g. Kalshi ticker: %s\n", mk[0].ticker.c_str());
  }
  bestFirst(picks);
  sportPicks = picks; sportsEverOk = true;
}

// ---------- screen ----------
void header(const char* title, uint16_t col) {
  tft.fillScreen(ST77XX_BLACK);
  tft.fillRect(0, 0, 240, 24, col);
  tft.setTextColor(ST77XX_BLACK); tft.setTextSize(2); tft.setCursor(6, 5); tft.print(title);
}
void drawPicks(const char* title, const std::vector<Pick>& picks, bool ok, uint16_t col) {
  header(title, col);
  tft.setTextSize(2);
  int y = 32, shown = 0;
  if (!ok) { tft.setTextColor(ST77XX_YELLOW); tft.setCursor(6, y); tft.print("loading..."); return; }
  for (const Pick& p : picks) {
    if (p.edge < MIN_EDGE || p.price < MIN_PRICE || p.price > MAX_PRICE) continue;
    tft.setTextColor(ST77XX_WHITE); tft.setCursor(4, y);
    String l = String(p.label.c_str()); if (l.length() > 15) l = l.substring(0, 15);
    tft.print(l); tft.setCursor(196, y); tft.setTextColor(p.side == "YES" || p.side == "UP" ? ST77XX_GREEN : ST77XX_RED); tft.print(p.side.c_str());
    y += 18;
    tft.setTextColor(ST77XX_CYAN); tft.setCursor(4, y);
    tft.printf("%2d%% vs %2dc  +%d", (int)lround(p.model * 100), (int)lround(p.price * 100), (int)lround(p.edge * 100));
    y += 22;
    if (++shown == 4) break;
  }
  if (!shown) { tft.setTextColor(ST77XX_YELLOW); tft.setCursor(6, y); tft.printf("no edges >= %dc", (int)(MIN_EDGE * 100)); }
  tft.setTextSize(1); tft.setTextColor(0x8410); tft.setCursor(4, 230); tft.print("model% vs price. Not advice. No fees.");
}
void drawCrypto() {
  header("CRYPTO 15 MIN", ST77XX_ORANGE);
  if (!cryptoEverOk) { tft.setTextSize(2); tft.setTextColor(ST77XX_YELLOW); tft.setCursor(6, 32); tft.print("loading..."); return; }
  long long now = nowUnix(); int y = 30;
  for (size_t i = 0; i < sizeof(COINS) / sizeof(COINS[0]); i++) {
    const CoinState& cs = coinState[i];
    if (!COINS[i].upDown15 || !cs.live) continue;
    long long left = cs.closeTs - now; if (left < 0) left = 0;
    tft.setTextSize(2); tft.setTextColor(ST77XX_WHITE); tft.setCursor(4, y);
    if (isnan(cs.start)) tft.printf("%s next window", COINS[i].name);
    else tft.printf("%s %+.0f %dm%02ds", COINS[i].name, cs.spot - cs.start, (int)(left / 60), (int)(left % 60));
    y += 18;
    bool up = cs.pUp >= 0.5;
    tft.setTextColor(up ? ST77XX_GREEN : ST77XX_RED); tft.setCursor(4, y);
    tft.printf("%s %2d%%", up ? "UP" : "DOWN", (int)lround((up ? cs.pUp : 1 - cs.pUp) * 100));
    tft.setTextColor(ST77XX_CYAN); tft.printf("  K %2d/%2dc", (int)lround(cs.yesBid * 100), (int)lround(cs.yesAsk * 100));
    y += 24;
  }
  tft.drawFastHLine(0, y, 240, 0x8410); y += 6;
  int shown = 0;
  for (const Pick& p : cryptoPicks) {
    if (p.edge < MIN_EDGE || p.price < MIN_PRICE || p.price > MAX_PRICE) continue;
    tft.setTextSize(2); tft.setTextColor(ST77XX_WHITE); tft.setCursor(4, y);
    String l = String(p.label.c_str()); if (l.length() > 15) l = l.substring(0, 15);
    tft.print(l); tft.setCursor(204, y); tft.setTextColor(p.side == "UP" || p.side == "YES" ? ST77XX_GREEN : ST77XX_RED); tft.print(p.side.c_str());
    y += 18; tft.setTextColor(ST77XX_CYAN); tft.setCursor(4, y);
    tft.printf("%2d%% vs %2dc  +%d", (int)lround(p.model * 100), (int)lround(p.price * 100), (int)lround(p.edge * 100));
    y += 22;
    if (++shown == 2 || y > 200) break;
  }
  if (!shown) { tft.setTextSize(2); tft.setTextColor(ST77XX_YELLOW); tft.setCursor(4, y); tft.printf("no edges >= %dc", (int)(MIN_EDGE * 100)); }
  tft.setTextSize(1); tft.setTextColor(0x8410); tft.setCursor(4, 230); tft.print("K = Kalshi UP bid/ask. Not advice. No fees.");
}
void drawStatus() {
  header("STATUS", ST77XX_WHITE);
  tft.setTextSize(2); tft.setTextColor(ST77XX_WHITE);
  tft.setCursor(4, 32); tft.printf("WiFi %s", WiFi.isConnected() ? "OK" : "DOWN");
  int y = 56;
  for (size_t i = 0; i < sizeof(COINS) / sizeof(COINS[0]); i++) {
    tft.setCursor(4, y); tft.printf("%s %.0f", COINS[i].name, coinState[i].spot); y += 20;
    tft.setCursor(4, y); tft.printf(" vol %.3f%% %dmk", coinState[i].vol * 100, coinState[i].markets); y += 22;
  }
  tft.setCursor(4, y); tft.printf("games %d match %d", sportsGames, sportsMatched); y += 22;
  tft.setTextSize(1); tft.setTextColor(ST77XX_YELLOW); tft.setCursor(4, y + 4); tft.print(lastError);
}
void drawPage() {
  if (page == 0) drawCrypto();
  else if (page == 1) drawPicks("SPORTS EDGES", sportPicks, sportsEverOk, ST77XX_GREEN);
  else drawStatus();
}

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  if (TFT_BL >= 0) { pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, HIGH); }
  SPI.begin(18, -1, 23, -1);
  tft.init(240, 240, SPI_MODE3);           // most 1.54" 240x240 modules need mode 3 (try SPI_MODE0 if the screen stays blank)
  tft.setRotation(2);
  header("CONNECTING", ST77XX_WHITE);
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  while (time(nullptr) < 1700000000) delay(200);   // wait for real time (needed for "closes in the next 2 hours")
  Serial.println("\nonline");
  updateCrypto(); lastCrypto = millis(); drawPage();
  updateSports(); lastSports = millis(); drawPage();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) { WiFi.reconnect(); delay(1000); }
  if (millis() - lastCrypto > CRYPTO_REFRESH_S * 1000UL) { updateCrypto(); lastCrypto = millis(); if (page == 0) drawPage(); }
  if (millis() - lastSports > SPORTS_REFRESH_S * 1000UL) { updateSports(); lastSports = millis(); if (page == 1) drawPage(); }
  bool pressed = digitalRead(BUTTON_PIN) == LOW;
  if (pressed || millis() - lastPage > PAGE_SECONDS * 1000UL) {
    page = (page + 1) % PAGES; lastPage = millis(); drawPage();
    if (pressed) { while (digitalRead(BUTTON_PIN) == LOW) delay(10); }
  }
  delay(20);
}
